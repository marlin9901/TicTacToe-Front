package main;

import main.kommunikation.*;
import main.ui.*;

public class TicTacToe {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TicTacToeTalker talker = new TicTacToeTalker("localhost", 8654);
		TicTacToeWindow window = new TicTacToeWindow(talker);
		talker.setWindow(window);
		talker.start();
	}

}
