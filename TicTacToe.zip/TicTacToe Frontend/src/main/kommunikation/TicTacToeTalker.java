package main.kommunikation;

import java.io.*;
import java.net.*;

import main.ui.*;

public class TicTacToeTalker extends Thread{
	private Socket socket = null;
	private PrintWriter out = null;
	private BufferedReader in = null;
	private boolean exiting = false;
	private TicTacToeWindow window;
	
	public TicTacToeTalker(String host, int port) {
		try {
			System.out.println("Der Talker can talk");
			socket = new Socket(host, port);
			out = new PrintWriter(socket.getOutputStream(), true);
			in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			
		}catch(UnknownHostException e) {
			System.out.println("Unknown Host");
			System.exit(1);
		}catch(IOException e) {
			System.out.println("I/O Error");
			System.exit(1);
		}
	}
	
	public void sendMessage(String msg) {
		out.println(msg);
	}
	
	public void run() {
		try {
			handleIncoming();
			
			out.close();
			in.close();
			socket.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("Irgendwas ist schief gegangen");
		}
		
		System.exit(0);
	}
	
	private void handleIncoming() {
		try {
			String msg;
			while((msg = in.readLine()) != null) interpreteMsg(msg); 
		} catch (IOException e) {
			System.out.println("IOError");
			
		}
	}

	private void interpreteMsg(String line) {
		System.out.println(line);
		if(line.equals("LOSE")) {
			window.youLose();
			return;
		}
		String[] reihen = line.split(";");
		String[][] felderAsStr = new String[3][];
		MyButton[][] buttons = window.getPanel().getButtons();
		
		if(reihen.length != 3) {
			return;
		}
		for (int i = 0; i < 3; i++) {
			felderAsStr[i] = reihen[i].split(":");
			if(felderAsStr[i].length != 3) {
				return;
			}
		}
		
		try {
			for(int i = 0; i < 3; i++) {
				for(int j = 0; j < 3; j++) {
					buttons[i][j].setText(Integer.parseInt(felderAsStr[i][j]));
				}
			}
		}catch(NumberFormatException e) {
			return;
		}
	}

	public void setWindow(TicTacToeWindow window) {
		this.window = window;
	}
}
