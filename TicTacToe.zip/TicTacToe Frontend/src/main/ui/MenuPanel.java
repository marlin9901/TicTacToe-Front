package main.ui;

import java.awt.Dimension;

import javax.swing.*;

import main.kommunikation.TicTacToeTalker;

public class MenuPanel extends JPanel{
	private final Dimension prefSize = new Dimension(600,600);
	private TicTacToeTalker talker;
	private String text;
	JTextField textField;
	
	
	public MenuPanel(TicTacToeTalker talker) {
		this.talker = talker;
		setFocusable(true);
		setPreferredSize(prefSize);
		textField = new JTextField();
	}
	
	public void changeText(String str) {
		this.text = str;
	}
	
	public void update() {
		textField.setText(text);
	}

}
