package main.ui;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

import main.kommunikation.TicTacToeTalker;

public class MyButton extends JButton{
	private int x;
	private int y;
	private boolean isEmpty;
	private Zeichen zeichen;
	private TicTacToeTalker talker;
	
	public MyButton(int x, int y, TicTacToeTalker talker) {
		this.x = x;
		this.y = y;
		isEmpty = true;
		zeichen = Zeichen.LEER;
		setFont(new Font(null, 0, 100));
		this.talker = talker;
	}
	
	public void addActionListener() {
		super.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				talker.sendMessage(x + ":" + y);
			}
			
		});
	}
	
	public void setText(int i) {
		setText(Zeichen.intToZeichen(i));
	}
	
	public void setText(Zeichen zeichen) {
		switch(zeichen){
		case LEER:
			isEmpty = true;
			setText(" ");
			break;
		case KREUZ:
			isEmpty = false;
			setText("X");
			break;
		case KREIS:
			isEmpty = false;
			setText("O");
			break;
		}
	
	}
	
}
