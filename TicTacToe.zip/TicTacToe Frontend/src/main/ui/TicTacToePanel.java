package main.ui;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

import main.kommunikation.TicTacToeTalker;

public class TicTacToePanel extends JPanel{
	
	private final Dimension prefSize = new Dimension(600,600);
	private final Dimension buttonSize = new Dimension(prefSize.width/3, prefSize.height/3);
	private MyButton[][] buttons;
	private TicTacToeTalker talker;
	
	public TicTacToePanel(TicTacToeTalker talker) {   
		this.talker = talker;
		setFocusable(true);
		setPreferredSize(prefSize);
		
		setLayout(new GridLayout(3,3,1,1));
		
		initButtons();
		
	}
	
	private void initButtons() {
		buttons = new MyButton[3][3];
		for (int i = 0; i <3; i++) {
			for (int j = 0; j < 3; j++) {
				buttons[i][j] = new MyButton(i,j, talker);
				add(buttons[i][j]);
				buttons[i][j].addActionListener();
			}
		}
		
	}
	
	public MyButton[][] getButtons() {
		return buttons;
	}
}
