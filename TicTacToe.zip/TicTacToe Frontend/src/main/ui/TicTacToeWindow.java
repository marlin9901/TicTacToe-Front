package main.ui;

import javax.swing.*;

import main.kommunikation.TicTacToeTalker;

public class TicTacToeWindow extends JFrame{

	private final TicTacToePanel gamePanel;
	private final MenuPanel menuPanel;
	private TicTacToeTalker talker;
	
	
	public TicTacToeWindow(TicTacToeTalker talker) {
		this.talker = talker;
		gamePanel = new TicTacToePanel(talker);
		menuPanel = new MenuPanel(talker);
		

		
		registerWindowListener();
		createMenu();
		
		add(gamePanel);
		pack();
		
		setTitle("TicTacToe");
		setLocation(10, 10);
		setResizable(false);
		setVisible(true);
		
	}
	
	public void youLose() {
		menuPanel.changeText("You Lose");
		menuPanel.update();
		remove(gamePanel);
		add(menuPanel);
		pack();
	}

	private void createMenu() {
		// TODO Auto-generated method stub
		
	}

	private void registerWindowListener() {
		// TODO Auto-generated method stub
		
	}
	

	public void setTalker(TicTacToeTalker talker) {
		this.talker = talker;
		
	}
	public TicTacToePanel getPanel() {
		return gamePanel;
	}
}
