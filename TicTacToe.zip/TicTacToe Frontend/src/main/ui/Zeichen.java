package main.ui;

public enum Zeichen {
	LEER, KREUZ, KREIS;
	
	public int toInt() {
		switch(this) {
		case LEER: return 0;
		case KREUZ: return 1;
		case KREIS: return -1;
		}
		return 0;
	}
	public static Zeichen intToZeichen(int i) {
		switch(i) {
		case 0: return LEER;
		case 1: return KREUZ;
		case -1: return KREIS;
		}
		return null;
	}
}
